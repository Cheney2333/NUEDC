#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f10x.h"

#define KEY_Pin GPIO_Pin_0
#define KEY_RCC_CLK RCC_APB2Periph_GPIOA

void KEY_GPIO_Config(void);
void KEY_Scan(void);

extern u8 flag;//�ⲿ��������

#endif
