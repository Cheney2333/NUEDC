#ifndef _ENCODER_T_H_
#define _ENCODER_T_H_

#include "stm32f10x.h"
	 
void Encoder_CAP_Init_L();
void Encoder_CAP_Init_R();
void Encoder_CAP_Init();
int Read_Encoder(u8 TIMX);
void Get_SpeedNow(int* CurrentVelcity_L,int* CurrentVelcity_R);

#endif

